// This file is auto-generated, don't edit it. Thanks.
package com.aliyun.sdk.service.agentcore20260804.models;

import com.aliyun.sdk.gateway.pop.*;
import darabonba.core.*;
import darabonba.core.async.*;
import darabonba.core.sync.*;
import darabonba.core.client.*;
import darabonba.core.RequestModel;
import darabonba.core.TeaModel;
import com.aliyun.sdk.gateway.pop.models.*;

/**
 * 
 * {@link OfflineSkillRequest} extends {@link RequestModel}
 *
 * <p>OfflineSkillRequest</p>
 */
public class OfflineSkillRequest extends Request {
    @com.aliyun.core.annotation.Path
    @com.aliyun.core.annotation.NameInMap("workspaceId")
    @com.aliyun.core.annotation.Validation(required = true)
    private String workspaceId;

    @com.aliyun.core.annotation.Path
    @com.aliyun.core.annotation.NameInMap("skillName")
    @com.aliyun.core.annotation.Validation(required = true)
    private String skillName;

    @com.aliyun.core.annotation.Body
    @com.aliyun.core.annotation.NameInMap("body")
    private OfflineSkillRequestBody body;

    private OfflineSkillRequest(Builder builder) {
        super(builder);
        this.workspaceId = builder.workspaceId;
        this.skillName = builder.skillName;
        this.body = builder.body;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static OfflineSkillRequest create() {
        return builder().build();
    }

@Override
    public Builder toBuilder() {
        return new Builder(this);
    }

    /**
     * @return workspaceId
     */
    public String getWorkspaceId() {
        return this.workspaceId;
    }

    /**
     * @return skillName
     */
    public String getSkillName() {
        return this.skillName;
    }

    /**
     * @return body
     */
    public OfflineSkillRequestBody getBody() {
        return this.body;
    }

    public static final class Builder extends Request.Builder<OfflineSkillRequest, Builder> {
        private String workspaceId; 
        private String skillName; 
        private OfflineSkillRequestBody body; 

        private Builder() {
            super();
        } 

        private Builder(OfflineSkillRequest request) {
            super(request);
            this.workspaceId = request.workspaceId;
            this.skillName = request.skillName;
            this.body = request.body;
        } 

        /**
         * <p>The workspace ID.</p>
         * <p>This parameter is required.</p>
         * 
         * <strong>example:</strong>
         * <p>550e8400-e29b-41d4-a716-446655440000</p>
         */
        public Builder workspaceId(String workspaceId) {
            this.putPathParameter("workspaceId", workspaceId);
            this.workspaceId = workspaceId;
            return this;
        }

        /**
         * <p>The Skill name.</p>
         * <p>This parameter is required.</p>
         * 
         * <strong>example:</strong>
         * <p>customer-service-skill</p>
         */
        public Builder skillName(String skillName) {
            this.putPathParameter("skillName", skillName);
            this.skillName = skillName;
            return this;
        }

        /**
         * <p>The request body.</p>
         */
        public Builder body(OfflineSkillRequestBody body) {
            String bodyShrink = shrink(body, "body", "json");
            this.putBodyParameter("body", bodyShrink);
            this.body = body;
            return this;
        }

        @Override
        public OfflineSkillRequest build() {
            return new OfflineSkillRequest(this);
        } 

    } 

    /**
     * 
     * {@link OfflineSkillRequest} extends {@link TeaModel}
     *
     * <p>OfflineSkillRequest</p>
     */
    public static class OfflineSkillRequestBody extends TeaModel {
        @com.aliyun.core.annotation.NameInMap("scope")
        private String scope;

        @com.aliyun.core.annotation.NameInMap("skillVersion")
        private String skillVersion;

        private OfflineSkillRequestBody(Builder builder) {
            this.scope = builder.scope;
            this.skillVersion = builder.skillVersion;
        }

        public static Builder builder() {
            return new Builder();
        }

        public static OfflineSkillRequestBody create() {
            return builder().build();
        }

        /**
         * @return scope
         */
        public String getScope() {
            return this.scope;
        }

        /**
         * @return skillVersion
         */
        public String getSkillVersion() {
            return this.skillVersion;
        }

        public static final class Builder {
            private String scope; 
            private String skillVersion; 

            private Builder() {
            } 

            private Builder(OfflineSkillRequestBody model) {
                this.scope = model.scope;
                this.skillVersion = model.skillVersion;
            } 

            /**
             * <p>The operation scope. Valid values:</p>
             * <ul>
             * <li>skill: the entire Skill.</li>
             * <li>version: a specified version.</li>
             * </ul>
             * 
             * <strong>example:</strong>
             * <p>version</p>
             */
            public Builder scope(String scope) {
                this.scope = scope;
                return this;
            }

            /**
             * <p>The Skill version number.</p>
             * 
             * <strong>example:</strong>
             * <p>0.0.1</p>
             */
            public Builder skillVersion(String skillVersion) {
                this.skillVersion = skillVersion;
                return this;
            }

            public OfflineSkillRequestBody build() {
                return new OfflineSkillRequestBody(this);
            } 

        } 

    }
}
