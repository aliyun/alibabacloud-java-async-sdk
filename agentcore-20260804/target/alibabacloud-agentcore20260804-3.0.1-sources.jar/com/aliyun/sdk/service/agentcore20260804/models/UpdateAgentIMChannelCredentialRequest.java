// This file is auto-generated, don't edit it. Thanks.
package com.aliyun.sdk.service.agentcore20260804.models;

import com.aliyun.sdk.gateway.pop.*;
import darabonba.core.*;
import darabonba.core.async.*;
import darabonba.core.sync.*;
import darabonba.core.client.*;
import darabonba.core.RequestModel;
import darabonba.core.TeaModel;
import com.aliyun.sdk.gateway.pop.models.*;

/**
 * 
 * {@link UpdateAgentIMChannelCredentialRequest} extends {@link RequestModel}
 *
 * <p>UpdateAgentIMChannelCredentialRequest</p>
 */
public class UpdateAgentIMChannelCredentialRequest extends Request {
    @com.aliyun.core.annotation.Path
    @com.aliyun.core.annotation.NameInMap("workspaceId")
    @com.aliyun.core.annotation.Validation(required = true)
    private String workspaceId;

    @com.aliyun.core.annotation.Path
    @com.aliyun.core.annotation.NameInMap("agentId")
    @com.aliyun.core.annotation.Validation(required = true)
    private String agentId;

    @com.aliyun.core.annotation.Path
    @com.aliyun.core.annotation.NameInMap("imChannelId")
    @com.aliyun.core.annotation.Validation(required = true)
    private String imChannelId;

    @com.aliyun.core.annotation.Body
    @com.aliyun.core.annotation.NameInMap("body")
    private UpdateAgentIMChannelCredentialRequestBody body;

    @com.aliyun.core.annotation.Query
    @com.aliyun.core.annotation.NameInMap("clientToken")
    private String clientToken;

    private UpdateAgentIMChannelCredentialRequest(Builder builder) {
        super(builder);
        this.workspaceId = builder.workspaceId;
        this.agentId = builder.agentId;
        this.imChannelId = builder.imChannelId;
        this.body = builder.body;
        this.clientToken = builder.clientToken;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static UpdateAgentIMChannelCredentialRequest create() {
        return builder().build();
    }

@Override
    public Builder toBuilder() {
        return new Builder(this);
    }

    /**
     * @return workspaceId
     */
    public String getWorkspaceId() {
        return this.workspaceId;
    }

    /**
     * @return agentId
     */
    public String getAgentId() {
        return this.agentId;
    }

    /**
     * @return imChannelId
     */
    public String getImChannelId() {
        return this.imChannelId;
    }

    /**
     * @return body
     */
    public UpdateAgentIMChannelCredentialRequestBody getBody() {
        return this.body;
    }

    /**
     * @return clientToken
     */
    public String getClientToken() {
        return this.clientToken;
    }

    public static final class Builder extends Request.Builder<UpdateAgentIMChannelCredentialRequest, Builder> {
        private String workspaceId; 
        private String agentId; 
        private String imChannelId; 
        private UpdateAgentIMChannelCredentialRequestBody body; 
        private String clientToken; 

        private Builder() {
            super();
        } 

        private Builder(UpdateAgentIMChannelCredentialRequest request) {
            super(request);
            this.workspaceId = request.workspaceId;
            this.agentId = request.agentId;
            this.imChannelId = request.imChannelId;
            this.body = request.body;
            this.clientToken = request.clientToken;
        } 

        /**
         * <p>The workspace ID.</p>
         * <p>This parameter is required.</p>
         * 
         * <strong>example:</strong>
         * <p>ws-1</p>
         */
        public Builder workspaceId(String workspaceId) {
            this.putPathParameter("workspaceId", workspaceId);
            this.workspaceId = workspaceId;
            return this;
        }

        /**
         * <p>The agent ID.</p>
         * <p>This parameter is required.</p>
         * 
         * <strong>example:</strong>
         * <p>agent-1</p>
         */
        public Builder agentId(String agentId) {
            this.putPathParameter("agentId", agentId);
            this.agentId = agentId;
            return this;
        }

        /**
         * <p>The IM channel ID.</p>
         * <p>This parameter is required.</p>
         * 
         * <strong>example:</strong>
         * <p>imc-1</p>
         */
        public Builder imChannelId(String imChannelId) {
            this.putPathParameter("imChannelId", imChannelId);
            this.imChannelId = imChannelId;
            return this;
        }

        /**
         * <p>The request body.</p>
         */
        public Builder body(UpdateAgentIMChannelCredentialRequestBody body) {
            String bodyShrink = shrink(body, "body", "json");
            this.putBodyParameter("body", bodyShrink);
            this.body = body;
            return this;
        }

        /**
         * <p>The reserved idempotence token. The backend does not provide persistent idempotence guarantees in the current phase.</p>
         * 
         * <strong>example:</strong>
         * <p>client-token-1</p>
         */
        public Builder clientToken(String clientToken) {
            this.putQueryParameter("clientToken", clientToken);
            this.clientToken = clientToken;
            return this;
        }

        @Override
        public UpdateAgentIMChannelCredentialRequest build() {
            return new UpdateAgentIMChannelCredentialRequest(this);
        } 

    } 

    /**
     * 
     * {@link UpdateAgentIMChannelCredentialRequest} extends {@link TeaModel}
     *
     * <p>UpdateAgentIMChannelCredentialRequest</p>
     */
    public static class UpdateAgentIMChannelCredentialRequestBody extends TeaModel {
        @com.aliyun.core.annotation.NameInMap("credential")
        @com.aliyun.core.annotation.Validation(required = true)
        private java.util.Map<String, String> credential;

        private UpdateAgentIMChannelCredentialRequestBody(Builder builder) {
            this.credential = builder.credential;
        }

        public static Builder builder() {
            return new Builder();
        }

        public static UpdateAgentIMChannelCredentialRequestBody create() {
            return builder().build();
        }

        /**
         * @return credential
         */
        public java.util.Map<String, String> getCredential() {
            return this.credential;
        }

        public static final class Builder {
            private java.util.Map<String, String> credential; 

            private Builder() {
            } 

            private Builder(UpdateAgentIMChannelCredentialRequestBody model) {
                this.credential = model.credential;
            } 

            /**
             * <p>The channel credentials. All fields must be provided and the field values must be non-empty strings. For DingTalk, use clientID and clientSecret. For Lark, use appId and appSecret. For WeCom, use botId and secret.</p>
             * <p>This parameter is required.</p>
             */
            public Builder credential(java.util.Map<String, String> credential) {
                this.credential = credential;
                return this;
            }

            public UpdateAgentIMChannelCredentialRequestBody build() {
                return new UpdateAgentIMChannelCredentialRequestBody(this);
            } 

        } 

    }
}
