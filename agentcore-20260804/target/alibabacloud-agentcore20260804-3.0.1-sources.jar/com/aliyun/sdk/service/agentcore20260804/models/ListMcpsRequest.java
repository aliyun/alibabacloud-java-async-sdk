// This file is auto-generated, don't edit it. Thanks.
package com.aliyun.sdk.service.agentcore20260804.models;

import com.aliyun.sdk.gateway.pop.*;
import darabonba.core.*;
import darabonba.core.async.*;
import darabonba.core.sync.*;
import darabonba.core.client.*;
import darabonba.core.RequestModel;
import darabonba.core.TeaModel;
import com.aliyun.sdk.gateway.pop.models.*;

/**
 * 
 * {@link ListMcpsRequest} extends {@link RequestModel}
 *
 * <p>ListMcpsRequest</p>
 */
public class ListMcpsRequest extends Request {
    @com.aliyun.core.annotation.Path
    @com.aliyun.core.annotation.NameInMap("workspaceId")
    @com.aliyun.core.annotation.Validation(required = true)
    private String workspaceId;

    @com.aliyun.core.annotation.Host
    @com.aliyun.core.annotation.NameInMap("regionId")
    private String regionId;

    @com.aliyun.core.annotation.Query
    @com.aliyun.core.annotation.NameInMap("customTag")
    private String customTag;

    @com.aliyun.core.annotation.Query
    @com.aliyun.core.annotation.NameInMap("maxResults")
    private Integer maxResults;

    @com.aliyun.core.annotation.Query
    @com.aliyun.core.annotation.NameInMap("name")
    private String name;

    @com.aliyun.core.annotation.Query
    @com.aliyun.core.annotation.NameInMap("nextToken")
    private String nextToken;

    @com.aliyun.core.annotation.Query
    @com.aliyun.core.annotation.NameInMap("officialTag")
    private String officialTag;

    @com.aliyun.core.annotation.Query
    @com.aliyun.core.annotation.NameInMap("searchType")
    private String searchType;

    @com.aliyun.core.annotation.Query
    @com.aliyun.core.annotation.NameInMap("usageActive")
    private Boolean usageActive;

    private ListMcpsRequest(Builder builder) {
        super(builder);
        this.workspaceId = builder.workspaceId;
        this.regionId = builder.regionId;
        this.customTag = builder.customTag;
        this.maxResults = builder.maxResults;
        this.name = builder.name;
        this.nextToken = builder.nextToken;
        this.officialTag = builder.officialTag;
        this.searchType = builder.searchType;
        this.usageActive = builder.usageActive;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static ListMcpsRequest create() {
        return builder().build();
    }

@Override
    public Builder toBuilder() {
        return new Builder(this);
    }

    /**
     * @return workspaceId
     */
    public String getWorkspaceId() {
        return this.workspaceId;
    }

    /**
     * @return regionId
     */
    public String getRegionId() {
        return this.regionId;
    }

    /**
     * @return customTag
     */
    public String getCustomTag() {
        return this.customTag;
    }

    /**
     * @return maxResults
     */
    public Integer getMaxResults() {
        return this.maxResults;
    }

    /**
     * @return name
     */
    public String getName() {
        return this.name;
    }

    /**
     * @return nextToken
     */
    public String getNextToken() {
        return this.nextToken;
    }

    /**
     * @return officialTag
     */
    public String getOfficialTag() {
        return this.officialTag;
    }

    /**
     * @return searchType
     */
    public String getSearchType() {
        return this.searchType;
    }

    /**
     * @return usageActive
     */
    public Boolean getUsageActive() {
        return this.usageActive;
    }

    public static final class Builder extends Request.Builder<ListMcpsRequest, Builder> {
        private String workspaceId; 
        private String regionId; 
        private String customTag; 
        private Integer maxResults; 
        private String name; 
        private String nextToken; 
        private String officialTag; 
        private String searchType; 
        private Boolean usageActive; 

        private Builder() {
            super();
        } 

        private Builder(ListMcpsRequest request) {
            super(request);
            this.workspaceId = request.workspaceId;
            this.regionId = request.regionId;
            this.customTag = request.customTag;
            this.maxResults = request.maxResults;
            this.name = request.name;
            this.nextToken = request.nextToken;
            this.officialTag = request.officialTag;
            this.searchType = request.searchType;
            this.usageActive = request.usageActive;
        } 

        /**
         * <p>The AgentCore workspace ID.</p>
         * <p>This parameter is required.</p>
         * 
         * <strong>example:</strong>
         * <p>workspace-id</p>
         */
        public Builder workspaceId(String workspaceId) {
            this.putPathParameter("workspaceId", workspaceId);
            this.workspaceId = workspaceId;
            return this;
        }

        /**
         * regionId.
         */
        public Builder regionId(String regionId) {
            this.putHostParameter("regionId", regionId);
            this.regionId = regionId;
            return this;
        }

        /**
         * <p>Filters results by custom tag. The tag must be an exact match.</p>
         * 
         * <strong>example:</strong>
         * <p>KnowledgeBase</p>
         */
        public Builder customTag(String customTag) {
            this.putQueryParameter("customTag", customTag);
            this.customTag = customTag;
            return this;
        }

        /**
         * <p>The maximum number of entries per page.</p>
         * 
         * <strong>example:</strong>
         * <p>20</p>
         */
        public Builder maxResults(Integer maxResults) {
            this.putQueryParameter("maxResults", maxResults);
            this.maxResults = maxResults;
            return this;
        }

        /**
         * <p>The MCP service name or service ID. Used together with SearchType.</p>
         * 
         * <strong>example:</strong>
         * <p>my-mcp-server</p>
         */
        public Builder name(String name) {
            this.putQueryParameter("name", name);
            this.name = name;
            return this;
        }

        /**
         * <p>The pagination token for the next page.</p>
         * 
         * <strong>example:</strong>
         * <p>next-page-token</p>
         */
        public Builder nextToken(String nextToken) {
            this.putQueryParameter("nextToken", nextToken);
            this.nextToken = nextToken;
            return this;
        }

        /**
         * <p>Filters results by official usage tag.</p>
         * 
         * <strong>example:</strong>
         * <p>KNOWLEDGE_BASE</p>
         */
        public Builder officialTag(String officialTag) {
            this.putQueryParameter("officialTag", officialTag);
            this.officialTag = officialTag;
            return this;
        }

        /**
         * <p>The name matching method. Takes effect only when Name is specified. Valid values:</p>
         * <ul>
         * <li>accurate: exact match.</li>
         * <li>blur: fuzzy match.</li>
         * </ul>
         * <p>Default value: blur.</p>
         * 
         * <strong>example:</strong>
         * <p>blur</p>
         */
        public Builder searchType(String searchType) {
            this.putQueryParameter("searchType", searchType);
            this.searchType = searchType;
            return this;
        }

        /**
         * <p>Specifies whether the service is still bound by the official template usage.</p>
         */
        public Builder usageActive(Boolean usageActive) {
            this.putQueryParameter("usageActive", usageActive);
            this.usageActive = usageActive;
            return this;
        }

        @Override
        public ListMcpsRequest build() {
            return new ListMcpsRequest(this);
        } 

    } 

}
